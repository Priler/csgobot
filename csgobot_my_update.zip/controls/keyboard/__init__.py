# Keyboard controls placeholder
